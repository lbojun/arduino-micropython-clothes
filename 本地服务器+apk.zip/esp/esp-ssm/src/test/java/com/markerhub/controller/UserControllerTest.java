package com.markerhub.controller;

import cn.hutool.crypto.SecureUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.markerhub.common.lang.Result;
import com.markerhub.entity.StudentTeacher;
import com.markerhub.entity.User;
import com.markerhub.entity.UserPrefer;
import com.markerhub.service.StudentTeacherService;
import com.markerhub.service.UserPreferService;
import com.markerhub.service.UserService;
import com.markerhub.service.impl.UserServiceImpl;
import com.markerhub.util.RecommendUtils;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class UserControllerTest {

    @Autowired
    private UserService userService;
    @Autowired
    private UserPreferService userPreferService;
    @Autowired
    private StudentTeacherService studentTeacherService;


    @Test
    void test() throws IOException {




        Date d = new Date();
        int hours = d.getHours();
        System.out.println(hours);
        int remainder=hours%3;
        System.out.println(remainder);
        if(remainder==1)
            hours=hours-2;
        if(remainder==0)
        hours=hours-1;
        String s_hour=hours+"时";
        System.out.println(s_hour);


        //新建一个URL对象，连接对象为天气网站
        URL ur1 = new URL("http://www.weather.com.cn/weather1d/101010200.shtml");
        //打开连接
        URLConnection conn = ur1.openConnection();
        //获得加载数据的字节输出流
        InputStream is = conn.getInputStream();
        //将一行一行字符输出流转化为String类型
        BufferedReader in = new BufferedReader(new InputStreamReader(is));
        StringBuffer buffer = new StringBuffer();
        String line = " ";
        while ((line = in.readLine()) != null)
        {
            buffer.append(line);
        }
        String text = buffer.toString();
        //将String类型的数据用空格分开
        String[] text1 = text.split(" ");
        String result="";
        //用循环匹配的方式找出对于信息
        for(int i=0;i<text1.length;i++)
        {
            if(text1[i].equals("class=\"winl\"></div></div><script>var"))
            {
                String message = text1[i+1].substring(text1[i+1].indexOf("{"),text1[i+1].indexOf("}")+1);


                message=message.substring(message.indexOf("[")+1,message.indexOf("]"));
                int a=message.indexOf(s_hour);
                System.out.println(a);
                System.out.println(message);

                message=message.substring(message.indexOf(s_hour),message.indexOf("\"",a));
                System.out.println(message);

                result=message;
            }
        }



        in.close();



       // while(matcher.find()) {
        //    System.out.println(matcher.group(0));
       // }
                //将String类型的数据用空格分开
            /*    String[] text1 = text.split(" ");
                //用循环匹配的方式找出对于信息
                for(int i=0;i<text1.length;i++)
                {
                    if(text1[i].equals("class=\"winl\"></div></div><script>var"))
                    {
                        System.out.println(text1[i-1]);
                        System.out.println(text1[i]);
                        System.out.println(text1[i+2]);
                        System.out.println(text1[i+3]);
                        String message = text1[i+1].substring(text1[i+1].indexOf("{"),text1[i+1].indexOf("}")+1);

                        System.out.println(1);
                        System.out.println(message);
                        message=message.substring(message.indexOf("[")+1,message.indexOf("]"));
                        System.out.println(2);
                        System.out.println(message);
                        message=message.substring(message.indexOf(s_hour)+7,message.indexOf(s_hour)+21);
                        System.out.println(3);
                        System.out.println(message);
                    }
                }

             */



                in.close();

            }







    }

