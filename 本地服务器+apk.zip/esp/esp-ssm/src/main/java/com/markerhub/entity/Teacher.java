package com.markerhub.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author 
 * @since 2021-04-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("m_teacher")
public class Teacher implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;

    private String region;

    private String grade;

    private String sex;

    private String age;

    private String description;

    private String picture;

    private Double educationscore;

    private Double sexscore;

    private Double difficultyscore;


}
