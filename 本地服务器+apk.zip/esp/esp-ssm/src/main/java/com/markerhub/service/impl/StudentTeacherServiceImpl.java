package com.markerhub.service.impl;

import com.markerhub.entity.StudentTeacher;
import com.markerhub.mapper.StudentTeacherMapper;
import com.markerhub.service.StudentTeacherService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 
 * @since 2021-04-15
 */
@Service
public class StudentTeacherServiceImpl extends ServiceImpl<StudentTeacherMapper, StudentTeacher> implements StudentTeacherService {

}
