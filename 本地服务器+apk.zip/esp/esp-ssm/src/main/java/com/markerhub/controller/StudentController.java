package com.markerhub.controller;



import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.markerhub.common.lang.Result;
import com.markerhub.entity.Student;
import com.markerhub.entity.User;
import com.markerhub.service.StudentService;
import com.markerhub.service.UserService;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 
 * @since 2021-04-12
 */
@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentService studentService;
    @Autowired
    private UserService userService;

    @PostMapping("/save")
    public Result save(@Validated @RequestBody Student student) {
       User user=  userService.getOne(new QueryWrapper<User>().eq("id", student.getId()));
        user.setStatus(1);
        userService.saveOrUpdate(user);
        studentService.saveOrUpdate(student);
        return Result.succ(student);
    }

    @GetMapping("/findById/{id}")
    public Result findById(@PathVariable("id") Integer id) {


        return Result.succ(studentService.getById(id));
    }
}


