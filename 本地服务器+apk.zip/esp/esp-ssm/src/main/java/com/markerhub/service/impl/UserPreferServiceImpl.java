package com.markerhub.service.impl;

import com.markerhub.entity.User;
import com.markerhub.entity.UserPrefer;
import com.markerhub.mapper.UserPreferMapper;
import com.markerhub.service.UserPreferService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 
 * @since 2021-04-15
 */
@Service
public class UserPreferServiceImpl extends ServiceImpl<UserPreferMapper, UserPrefer> implements UserPreferService {
//@Autowired
//UserPreferService userPreferService;
//    public ArrayList(UserPrefer)  getAll{
//        ArrayList AllUserPref = new ArrayList<UserPrefer>();
//        userPreferService.get
//        AllUserPref.add()
//
//
//    }


}
