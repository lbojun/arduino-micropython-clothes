package com.markerhub.controller;


import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.markerhub.common.lang.Result;
import com.markerhub.entity.Blog;
import com.markerhub.entity.Student;
import com.markerhub.entity.User;
import com.markerhub.mapper.UserMapper;
import com.markerhub.service.UserService;
import com.markerhub.util.WeatherUtil;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 关注公众号：MarkerHub
 * @since 2020-05-25
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
   private UserService userService;
    @Autowired
    private UserMapper userMapper;



    @RequiresAuthentication
    @GetMapping("/index")
    public Result index() {
        User user = userService.getById(1L);
        return Result.succ(user);
    }

    @PostMapping("/save")
    public Result save(@Validated @RequestBody User user) {
        return Result.succ(user);
    }


    @GetMapping("/findAll")
    public Result list(@RequestParam(defaultValue = "1") Integer currentPage) {

        Page page = new Page(currentPage, 6);

        IPage pageData = userService.page(page, new QueryWrapper<User>().orderByDesc("id"));

        return Result.succ(pageData);
    }
    @DeleteMapping("/deleteById/{id}")
    public Result deleteById(@PathVariable("id") Integer id){
        userService .removeById(id);
        return  Result.succ("成功删除");
    }
    @GetMapping("/weather")
    public String weather(){
        String result="暂时无法获得天气信息";
        try {

           result=  WeatherUtil.getWeather();
            return result;

        }
        catch (IOException e){
            e.printStackTrace();
            return result;
        }

    }
    @GetMapping("/remind")
    public String remind(@RequestParam String t,@RequestParam String h){

        String result="false";
        try {

            result=  WeatherUtil.remind(t,h);
            return result;

        }
        catch (IOException e){
            e.printStackTrace();
            return result;
        }

    }


}
