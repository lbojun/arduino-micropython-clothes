package com.markerhub.mapper;

import com.markerhub.entity.Teacher;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 
 * @since 2021-04-12
 */
public interface TeacherMapper extends BaseMapper<Teacher> {

}
