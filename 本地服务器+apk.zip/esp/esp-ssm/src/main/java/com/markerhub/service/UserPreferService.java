package com.markerhub.service;

import com.markerhub.entity.UserPrefer;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 
 * @since 2021-04-15
 */
public interface UserPreferService extends IService<UserPrefer> {


}
