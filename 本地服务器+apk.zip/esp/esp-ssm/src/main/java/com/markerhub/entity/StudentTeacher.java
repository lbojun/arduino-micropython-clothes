package com.markerhub.entity;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author 
 * @since 2021-04-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class StudentTeacher implements Serializable {

    private static final long serialVersionUID = 1L;

    private String sUsername;

    private Long tId;

    private Integer score;

    private String comment;


}
