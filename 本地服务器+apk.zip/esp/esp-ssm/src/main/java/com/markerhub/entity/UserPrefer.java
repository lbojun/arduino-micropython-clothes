package com.markerhub.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 *
 * @since 2021-04-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class UserPrefer implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String grade;

    private String username;

    private Double educationPrefer;

    @TableField("Course_difficulty_prefer")
    private Double courseDifficultyPrefer;

    @TableField("same_sex_prefer")
    private Double sameSexPrefer;


}
