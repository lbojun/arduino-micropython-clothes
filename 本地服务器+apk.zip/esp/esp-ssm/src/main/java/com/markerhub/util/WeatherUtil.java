package com.markerhub.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WeatherUtil {
    public static String getWeather() throws IOException {
        Date d = new Date();
        int hours = d.getHours();
        int remainder=hours%3;
        if(remainder==1)
            hours=hours-2;
        if(remainder==0)
        {hours=hours-1;}
        String s_hour=hours+"时";


        //新建一个URL对象，连接对象为天气网站
        URL ur1 = new URL("http://www.weather.com.cn/weather1d/101010200.shtml");
        //打开连接
        URLConnection conn = ur1.openConnection();
        //获得加载数据的字节输出流
        InputStream is = conn.getInputStream();
        //将一行一行字符输出流转化为String类型
        BufferedReader in = new BufferedReader(new InputStreamReader(is));
        StringBuffer buffer = new StringBuffer();
        String line = " ";
        while ((line = in.readLine()) != null)
        {
            buffer.append(line);
        }
        String text = buffer.toString();
        //将String类型的数据用空格分开
        String[] text1 = text.split(" ");
        String result="";
        //用循环匹配的方式找出对于信息
        for(int i=0;i<text1.length;i++)
        {
            if(text1[i].equals("class=\"winl\"></div></div><script>var"))
            {
                String message = text1[i+1].substring(text1[i+1].indexOf("{"),text1[i+1].indexOf("}")+1);


                message=message.substring(message.indexOf("[")+1,message.indexOf("]"));
                int a=message.indexOf(s_hour);
                System.out.println(a);
                System.out.println(message);

                message=message.substring(message.indexOf(s_hour),message.indexOf("\"",a));
                System.out.println(message);

                result=message;
            }
        }



        in.close();
        return  result;

    };
    public static String remind(String t,String h)  throws IOException {
        System.out.println(t);
        System.out.println(h);
        String s[]=ambientWeather();
        Double c_t=Double.parseDouble(t);
        Double c_h=Double.parseDouble(h);
        Double rain=Double.parseDouble(s[2]);

        Double ambient_t=Double.parseDouble(s[0]);
        Double ambient_h=Double.parseDouble(s[1]);
        System.out.println("环境温度:"+ambient_t);
        System.out.println("环境湿度:"+ambient_h);
        System.out.println("降水量："+s[2]);
        if(rain>50)
            return "要下雨了，快收衣服";
        if(c_h<=ambient_h-1)
            return "true";
        else
            return "false";






    };
    public static String[] ambientWeather()  throws IOException {



        //新建一个URL对象，连接对象为天气网站
        URL ur1 = new URL("http://www.weather.com.cn/weather1d/101010200.shtml");
        //打开连接
        URLConnection conn = ur1.openConnection();
        //获得加载数据的字节输出流
        InputStream is = conn.getInputStream();
        //将一行一行字符输出流转化为String类型
        BufferedReader in = new BufferedReader(new InputStreamReader(is));
        StringBuffer buffer = new StringBuffer();
        String line = " ";
        while ((line = in.readLine()) != null)
        {
            buffer.append(line);

        }
        String text = buffer.toString();
        String regExpression="\"od27\".*?,";
        String regExpression2="\"od22\".*?,";
        String regExpression3="\"od26\".*?,";
        String text2="\"od27\"aaa,,,";

        //①创建表达式对象
        Pattern checkPattern = Pattern.compile(regExpression);
        Pattern checkPattern2 = Pattern.compile(regExpression2);
        Pattern checkPattern3 = Pattern.compile(regExpression3);
        //②创建Match对象
        Matcher matcher1 = checkPattern.matcher(text);
        matcher1.find();

        Matcher matcher2= checkPattern2.matcher(text);
        String s1=matcher1.group();


        matcher2.find();
        String s2=matcher2.group();

        Matcher matcher3=checkPattern3.matcher(text);
        matcher3.find();
        String s3=matcher3.group();



        String h=s1.substring(8,10);
        String t=s2.substring(8,10);
        String rain=s3.substring(s3.indexOf(":")+2,s3.length()-2);

        String [] result={t,h,rain};
        return result;
    }




}

