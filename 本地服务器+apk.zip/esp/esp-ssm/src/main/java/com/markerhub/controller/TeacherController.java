package com.markerhub.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.markerhub.common.lang.Result;
import com.markerhub.entity.Student;
import com.markerhub.entity.Teacher;
import com.markerhub.entity.User;
import com.markerhub.service.TeacherService;
import com.markerhub.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 
 * @since 2021-04-12
 */
@RestController
@RequestMapping("/teacher")

public class TeacherController {

    @Autowired
    private TeacherService teacherservice;
    @Autowired
    private UserService userService;
 //   @PostMapping("/choose")
  //  public Result choose(@RequestParam String username,@RequestParam String id){
//}
    @PostMapping("/save")
    public Result save(@Validated @RequestBody Teacher teacher) {
        User user=  userService.getOne(new QueryWrapper<User>().eq("id", teacher.getId()));
        user.setStatus(2);
        userService.saveOrUpdate(user);
        teacherservice.saveOrUpdate(teacher);
        return Result.succ(teacher);
    }
    @GetMapping("/findById/{id}")
    public Result findById(@PathVariable("id") String id) {

        Integer _id=Integer.valueOf(id);
        return Result.succ(teacherservice.getById(_id));
    }


    @GetMapping("/findAll")
    public Result list(@RequestParam(defaultValue = "1") Integer currentPage ,@RequestParam String sex,@RequestParam String grade) {


        Page page = new Page(2, 6);
        System.out.println(page.toString());
        QueryWrapper <Teacher> queryWrapper=new QueryWrapper();
        if(sex!="")
        queryWrapper.eq("sex",sex);
        if(grade!="")
        queryWrapper.eq("grade",grade);


        IPage pageData = teacherservice.page(page, queryWrapper.orderByDesc("id"));

        return Result.succ(pageData);
    }


}
