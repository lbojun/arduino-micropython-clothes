package com.markerhub.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.markerhub.common.lang.Result;
import com.markerhub.entity.StudentTeacher;
import com.markerhub.entity.Teacher;
import com.markerhub.entity.User;
import com.markerhub.service.StudentTeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 
 * @since 2021-04-15
 */
@RestController
@RequestMapping("/student_teacher")
public class StudentTeacherController {
    @Autowired
    StudentTeacherService studentTeacherService;
     @PostMapping("/save")
     public Result Save(@RequestParam String username,@RequestParam String id){
         StudentTeacher studentTeacher=new StudentTeacher();
         Integer _id=Integer.valueOf(id);
         studentTeacher.setTId((long)_id);
         studentTeacher.setSUsername(username);
         studentTeacherService.save(studentTeacher);
         return Result.succ(studentTeacher);



     }
    @GetMapping("/findAll")
    public Result list(@RequestParam(defaultValue = "1") Integer currentPage ,@RequestParam String username) {



        Page page = new Page(currentPage, 6);
        QueryWrapper <StudentTeacher> queryWrapper=new QueryWrapper();

        queryWrapper.eq("s_username",username);

        IPage pageData = studentTeacherService.page(page, queryWrapper);

        return Result.succ(pageData);
    }

}
