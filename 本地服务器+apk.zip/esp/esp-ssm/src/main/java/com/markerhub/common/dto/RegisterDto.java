package com.markerhub.common.dto;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Date;
@Data
public class RegisterDto implements Serializable {
    @NotBlank(message = "昵称不能为空")
    private String username;

    @NotBlank(message = "密码不能为空")
    private String password;

    private String email;

    private String sex;

    private String grade;

    private String name;

    private String[] subject;

    private Double sexprefer;

    private  Double education;

    private  Double difficulty;

    private String age;

    private Boolean checked1;
    private Boolean checked2;
    private Boolean checked3;
    private Boolean checked4;
    private Boolean checked5;
    private Boolean checked6;
    private Boolean checked7;





}
