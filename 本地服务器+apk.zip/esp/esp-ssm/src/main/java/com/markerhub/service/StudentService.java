package com.markerhub.service;

import com.markerhub.entity.Student;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 
 * @since 2021-04-12
 */
public interface StudentService extends IService<Student> {

}
