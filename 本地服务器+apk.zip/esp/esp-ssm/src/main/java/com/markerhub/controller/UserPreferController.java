package com.markerhub.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.markerhub.common.lang.Result;
import com.markerhub.entity.StudentTeacher;
import com.markerhub.entity.Teacher;
import com.markerhub.entity.User;
import com.markerhub.entity.UserPrefer;
import com.markerhub.mapper.StudentTeacherMapper;
import com.markerhub.mapper.UserMapper;
import com.markerhub.mapper.UserPreferMapper;
import com.markerhub.service.StudentTeacherService;
import com.markerhub.service.TeacherService;
import com.markerhub.service.UserPreferService;
import com.markerhub.service.impl.UserPreferServiceImpl;
import com.markerhub.util.RecommendUtils;
import net.sf.saxon.functions.Sum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.sql.ResultSet;
import java.util.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 
 * @since 2021-04-15
 */
@RestController
@RequestMapping("/userPrefer")
public class UserPreferController {

    @Autowired
  private   UserPreferService userPreferService;
    @Autowired
   private UserPreferMapper userPreferMapper;
    @Autowired
   private TeacherService teacherService;

    @Autowired
  private   StudentTeacherService studentTeacherService;


    @PostMapping("/save")
    public Result save(@RequestBody UserPrefer userPrefer) {
        userPreferService.saveOrUpdate(userPrefer);

        return Result.succ(userPrefer);
    }

    @GetMapping("/findAll")
    public Result list(@RequestParam(defaultValue = "1") Integer currentPage) {

        Page page = new Page(currentPage, 6);

        IPage pageData = userPreferService.page(page, new QueryWrapper<UserPrefer>());

        return Result.succ(pageData);
    }
    @GetMapping("/recommend")
    public Result result(@RequestParam String id,@RequestParam(defaultValue = "1") Integer currentPage)
    {

        Integer _id=Integer.valueOf(id);
        UserPrefer userPrefer1=userPreferService.getById(_id);
        QueryWrapper<UserPrefer> queryWrapper=new QueryWrapper();
        System.out.println(userPrefer1);



        List<UserPrefer> userPrefersList=userPreferService.list(queryWrapper);
        for(UserPrefer item:userPrefersList){
            QueryWrapper<StudentTeacher> condition = new QueryWrapper<>();
            condition.eq("s_username", item.getUsername()).last("limit 1");

        }
        System.out.println(userPrefersList.toString());


        String nearest=RecommendUtils.computeNearestNeighbor(userPrefer1,userPrefersList);
        List<StudentTeacher> list=studentTeacherService.list(new QueryWrapper<StudentTeacher>().eq("s_username",nearest));
        List<Long> recommandList = new ArrayList<>();
        for(StudentTeacher item :list){
            recommandList.add(item.getTId());
        }
        System.out.println(recommandList.toString());

        Page page = new Page(currentPage, 6);
        QueryWrapper <Teacher> TqueryWrapper=new QueryWrapper();
        TqueryWrapper.in("id",recommandList);


        IPage pageData = teacherService.page(page, TqueryWrapper.orderByDesc("id"));

        System.out.println(list);
        return  Result.succ(pageData);
    }
    @GetMapping("/update")
    public Result result(@RequestParam String sid,@RequestParam String tid){
       UserPrefer u1= userPreferService.getById(sid);
       Teacher t1=teacherService.getById(tid);
       u1.setSameSexPrefer((u1.getSameSexPrefer()+t1.getSexscore())/2);
       u1.setEducationPrefer(u1.getEducationPrefer()/2+t1.getEducationscore()/2);
       u1.setCourseDifficultyPrefer(u1.getCourseDifficultyPrefer()/2+t1.getDifficultyscore()/2);
       userPreferService.saveOrUpdate(u1);
       return Result.succ(u1);

    }

}

