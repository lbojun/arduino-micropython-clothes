package com.markerhub.controller;

import cn.hutool.core.map.MapUtil;
import cn.hutool.crypto.SecureUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.markerhub.common.dto.LoginDto;
import com.markerhub.common.dto.RegisterDto;
import com.markerhub.common.lang.Result;
import com.markerhub.entity.Student;
import com.markerhub.entity.User;
import com.markerhub.entity.UserPrefer;
import com.markerhub.mapper.UserMapper;
import com.markerhub.service.StudentService;
import com.markerhub.service.UserPreferService;
import com.markerhub.service.UserService;
import com.markerhub.util.JwtUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Objects;

@RestController
public class AccountController {

    @Autowired
   private UserService userService;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private UserPreferService userPreferService;
    @Autowired
    private StudentService studentService;


    @Autowired
   private JwtUtils jwtUtils;
    @RequestMapping("/hello")
    public String hello() {
        return "Hello Spring Boot!";
    }


    @PostMapping("/register")
    public Result register( @RequestBody RegisterDto registerDto,HttpServletResponse response)
    {

      /*  QueryWrapper<User> condition = new QueryWrapper<>();
        condition.eq("username", loginDto.getUsername()).last("limit 1");
        Integer integer = userMapper.selectCount(condition);
        if(integer!=0)
        { return Result.fail("用户名重复");
        }

        User user = new User();
        String password=loginDto.getPassword();
        String username=loginDto.getUsername();
        String email=loginDto.getEmail();

        String md5Str = SecureUtil.md5(password);
        user.setPassword(md5Str);
        user.setUsername(username);
        user.setStatus(0);
        user.setEmail(email);
        System.out.println(user);
        userService.save(user);
        return Result.succ(MapUtil.builder()
                .put("id", user.getId())
                .put("username", user.getUsername())
                .put("status", user.getStatus())
                .put("email", user.getEmail())
                .map()
        );

       */ QueryWrapper<User> condition = new QueryWrapper<>();
        condition.eq("username", registerDto.getUsername()).last("limit 1");
        Integer integer = userMapper.selectCount(condition);
        if(integer!=0)
        { return Result.fail("用户名重复");
        }

        User user = new User();
        String password=registerDto.getPassword();
        String username=registerDto.getUsername();
        String email=registerDto.getEmail();

        String md5Str = SecureUtil.md5(password);
        user.setPassword(md5Str);
        user.setUsername(username);
        user.setStatus(0);
        user.setEmail(email);
        System.out.println(user);
        userService.save(user);


        User new_user=userService.getOne(condition);
          Student student=new Student();
        student.setId(new_user.getId());
        student.setAge(registerDto.getAge());
        student.setGrade(registerDto.getGrade());
        student.setName(registerDto.getName());
        student.setRegion("山东");
        studentService.save(student);

        double d_pref = 5;
        double s_pref =5;
        double e_pref=5;
        if(registerDto.getChecked1()){
            e_pref-=2;

        }
        if(registerDto.getChecked2()){
            d_pref-=2.5;

        }
        if(registerDto.getChecked3()){
            d_pref-=1.5;

        }
        if(registerDto.getChecked4()){
            d_pref+=4;

        }
        if(registerDto.getChecked5()){
            e_pref+=3.5;

        }
        if(registerDto.getChecked6()){
            s_pref-=2.5;

        }
        if(registerDto.getChecked7()){
            s_pref+=2.5;

        }

        UserPrefer userPrefer=new UserPrefer();
        userPrefer.setId(new_user.getId());
        userPrefer.setCourseDifficultyPrefer(d_pref);
        userPrefer.setSameSexPrefer(s_pref);
        userPrefer.setEducationPrefer(e_pref);
        userPrefer.setUsername(new_user.getUsername());
        userPreferService.save(userPrefer);




        System.out.println(registerDto.toString());
        return  Result.succ(registerDto);

    }
    @PostMapping("/login")
    public Result login(@Validated @RequestBody LoginDto loginDto, HttpServletResponse response) {

        User user = userService.getOne(new QueryWrapper<User>().eq("username", loginDto.getUsername()));
        Assert.notNull(user, "用户不存在");

        if(!user.getPassword().equals(SecureUtil.md5(loginDto.getPassword()))){
            return Result.fail("密码不正确");
        }
        String jwt = jwtUtils.generateToken(user.getId());

        response.setHeader("Authorization", jwt);
        response.setHeader("Access-control-Expose-Headers", "Authorization");

        return Result.succ(MapUtil.builder()
                .put("id", user.getId())
                .put("username", user.getUsername())
                .put("status", user.getStatus())
                .put("email", user.getEmail())
                .map()
        );



    }

    @RequiresAuthentication
    @GetMapping("/logout")
    public Result logout() {
        SecurityUtils.getSubject().logout();
        return Result.succ(null);
    }

}
