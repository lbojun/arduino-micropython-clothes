package com.markerhub.util;

import com.markerhub.entity.Teacher;
import com.markerhub.entity.UserPrefer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class RecommendUtils {

    public static double pearson_dis(UserPrefer u1, UserPrefer u2 )
    {
        double Ex=u1.getCourseDifficultyPrefer()+u1.getEducationPrefer()+u1.getSameSexPrefer();
        double Ey=u2.getCourseDifficultyPrefer()+u2.getEducationPrefer()+u2.getSameSexPrefer();
        double Ex2=u1.getCourseDifficultyPrefer()*u1.getCourseDifficultyPrefer()+u1.getSameSexPrefer()*u1.getSameSexPrefer()+u1.getEducationPrefer()*u1.getEducationPrefer();
        double Ey2= Math.pow(u2.getCourseDifficultyPrefer(),2)+Math.pow(u2.getEducationPrefer(),2)+Math.pow(u2.getSameSexPrefer(),2);
        double Exy=u1.getCourseDifficultyPrefer()*u2.getCourseDifficultyPrefer()+u1.getEducationPrefer()*u2.getEducationPrefer()+u1.getSameSexPrefer()*u2.getSameSexPrefer();
        double numerator=Exy-Ex*Ey/3;
        double denominator=Math.sqrt((Ex2-Math.pow(Ex,2)/3)*(Ey2-Math.pow(Ey,2)/3));


        double o1=Math.pow(u1.getCourseDifficultyPrefer()-u2.getCourseDifficultyPrefer(),2);
        double o2=Math.pow(u1.getEducationPrefer()-u2.getEducationPrefer(),2);
        double o3=Math.pow(u1.getSameSexPrefer()-u2.getSameSexPrefer(),2);
        return o1+o2+o3;

    }
    public  static  String  computeNearestNeighbor(UserPrefer u1, List<UserPrefer> userPrefers) {
        Map<String, Double> distances = new HashMap<>();
        double min = Integer.MAX_VALUE;
        String nearest="";




        for (int i = 0; i < userPrefers.size(); i++) {
            UserPrefer u2=userPrefers.get(i);


            if (!u2.getId().equals(u1.getId())) {
                double distance = pearson_dis(u1,u2);
                distances.put(u2.getUsername(),distance);

            }


        }
        for (Map.Entry<String, Double> entry : distances.entrySet()
             ) {
            if(entry.getValue()<min) {
                min = entry.getValue();
                nearest=entry.getKey();
            }


        }
        System.out.println(distances);

        return nearest;


    }

}
