package com.markerhub.mapper;

import com.markerhub.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 关注公众号：MarkerHub
 * @since 2020-05-25
 */
@Repository("userMapper")
public interface UserMapper extends BaseMapper<User> {

}
