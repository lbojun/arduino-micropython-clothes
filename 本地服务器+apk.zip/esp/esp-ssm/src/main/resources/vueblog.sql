

SET FOREIGN_KEY_CHECKS=0;


-- ----------------------------
-- Records of m_user
-- ----------------------------
INSERT INTO `m_user` VALUES ('1', 'markerhub', 'https://image-1300566513.cos.ap-guangzhou.myqcloud.com/upload/images/5a9f48118166308daba8b6da7e466aab.jpg', null, '96e79218965eb72c92a549dd5a330112', '0', '2020-04-20 10:44:01', null);
CREATE TABLE `m_student` (
                             `id` bigint(20) NOT NULL ,
                             name varchar(16) DEFAULT NULL,
                             region varchar (32) DEFAULT NULL ,
                             grade  varchar (32) DEFAULT NULL,
                             age  varchar (32) DEFAULT NULL,
                             sex varchar (32) DEFAULT NULL,
                             PRIMARY KEY (`id`)

) ENGINE=InnoDB  DEFAULT CHARSET=utf8;
drop table m_teacher if exists
CREATE TABLE m_teacher(
                          id bigint(20) NOT NULL primary key,
                          name varchar(16) DEFAULT NULL,
                          region varchar (32) DEFAULT NULL ,
                          grade  varchar (32) DEFAULT NULL,
                          sex varchar(32) DEFAULT NULL,
                          age  varchar (32) DEFAULT NULL,
                          description varchar(255) DEFAULT NULL,
                          state int(5) DEFAULT
                          picture varchar (64) DEFAULT NULL,
                          sexscore double(3) DEFAULT 5,
                          difficultyscore double(3) DEFAULT 5,
                          educationscore double(3) DEFAULT 5,
)

CREATE TABLE Student_Teacher(
     s_username, varchar (64)
     t_id,  bigint(20),
     score int(2),
     commnet varchar (256)
     }

DROP TABLE IF EXISTS user_prefer;
CREATE TABLE  user_prefer(
                             id bigint(20),
                             username varchar(64),
                             grade varchar(64),
                             education_prefer int(2),
                             Same_sex_prefer int(2),
                             Course_difficulty_prefer int(2)

);


ALTER TABLE m_user AUTO_INCREMENT=100
INSERT INTO m_user (username,password,status) VALUES ('admin','e10adc3949ba59abbe56e057f20f883e','3');

INSERT INTO m_user (username,password,status) VALUES ('user1','e10adc3949ba59abbe56e057f20f883e','1');
INSERT INTO m_user (username,password,status) VALUES ('user2','e10adc3949ba59abbe56e057f20f883e','1');
INSERT INTO m_user (username,password,status) VALUES ('user3','e10adc3949ba59abbe56e057f20f883e','1');
INSERT INTO m_user (username,password,status) VALUES ('user4','e10adc3949ba59abbe56e057f20f883e','1');
INSERT INTO m_user (username,password,status) VALUES ('user5','e10adc3949ba59abbe56e057f20f883e','1');
INSERT INTO m_user (username,password,status) VALUES ('user6','e10adc3949ba59abbe56e057f20f883e','1');

INSERT INTO m_user (username,password,status) VALUES ('teacher1','e10adc3949ba59abbe56e057f20f883e','2');
INSERT INTO m_user (username,password,status) VALUES ('teacher2','e10adc3949ba59abbe56e057f20f883e','2');
INSERT INTO m_user (username,password,status) VALUES ('teacher3','e10adc3949ba59abbe56e057f20f883e','2');
INSERT INTO m_user (username,password,status) VALUES ('teacher4','e10adc3949ba59abbe56e057f20f883e','2');
INSERT INTO m_user (username,password,status) VALUES ('teacher5','e10adc3949ba59abbe56e057f20f883e','2');
INSERT INTO m_user (username,password,status) VALUES ('teacher6','e10adc3949ba59abbe56e057f20f883e','2');
INSERT INTO m_student(id,name,sex,region,grade) VALUES (100,'李一','男','山东','高中');
INSERT INTO m_student(id,name,sex,region,grade) VALUES (101,'李二','男','山东','高中');
INSERT INTO m_student(id,name,sex,region,grade) VALUES (102,'李三','男','山东','高中');
INSERT INTO m_student(id,name,sex,region,grade) VALUES (103,'李四','男','山东','初中');
INSERT INTO m_student(id,name,sex,region,grade) VALUES (104,'李五','男','山东','初中');
INSERT INTO m_student(id,name,sex,region,grade) VALUES (105,'李六','男','山东','初中');

INSERT INTO m_teacher(id,name,sex,age,region,grade,description) VALUES (106,'刘一','男','山东','29','高中','本科清华，教学风格幽默');
INSERT INTO m_teacher(id,name,sex,age,region,grade,description) VALUES (107,'刘二','女','山东','30','高中','本硕985，教学风格严肃');
INSERT INTO m_teacher(id,name,sex,age,region,grade,description) VALUES (108,'刘三','男','山东','31','高中','普通一本毕业，教学风格幽默');
INSERT INTO m_teacher(id,name,sex,age,region,grade,description) VALUES (109,'刘四','女','山东','32','高中','普通一本毕业，教龄长，教学风格幽默');
INSERT INTO m_teacher(id,name,sex,age,region,grade,description) VALUES (110,'刘一','男','山东','20','初中','大学生，教人有耐心');
INSERT INTO m_teacher(id,name,sex,age,region,grade,description) VALUES (111,'刘一','男','山东','21','高中','大学生,有竞赛经历');
INSERT INTO student_teacher(s_username, t_id,score,comment) VALUES ('user1',106,8,'不错');
INSERT INTO student_teacher(s_username, t_id,score,comment) VALUES ('user1',107,8,'不错');
INSERT INTO student_teacher(s_username, t_id,score,comment) VALUES ('user2',108,8,'不错');
INSERT INTO student_teacher(s_username, t_id,score,comment) VALUES ('user2',109,8,'不错');
INSERT INTO student_teacher(s_username, t_id,score,comment) VALUES ('user3',106,8,'不错');
INSERT INTO student_teacher(s_username, t_id,score,comment) VALUES ('user4',109,7,'不错');
INSERT INTO student_teacher(s_username, t_id,score,comment) VALUES ('user5',110,8,'不错');
INSERT INTO student_teacher(s_username, t_id,score,comment) VALUES ('user6',111,8,'不错');
INSERT INTO user_prefer(id,username,grade,education_prefer,same_sex_prefer,Course_difficulty_prefer)VALUES (100,'user1','高中',8,8,8);
INSERT INTO user_prefer(id,username,grade,education_prefer,same_sex_prefer,Course_difficulty_prefer)VALUES (101,'user2','高中',3,3,1);
INSERT INTO user_prefer(id,username,grade,education_prefer,same_sex_prefer,Course_difficulty_prefer)VALUES (102,'user3','高中',4,1,9);
INSERT INTO user_prefer(id,username,grade,education_prefer,same_sex_prefer,Course_difficulty_prefer)VALUES (103,'user4','高中',4,8,9);
INSERT INTO user_prefer(id,username,grade,education_prefer,same_sex_prefer,Course_difficulty_prefer)VALUES (104,'user5','高中',2,4,3);
INSERT INTO user_prefer(id,username,grade,education_prefer,same_sex_prefer,Course_difficulty_prefer)VALUES (105,'user6','高中',6,4,5);


